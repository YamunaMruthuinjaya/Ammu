package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.SubService;
import com.cg.dao.IServiceDao;

@Service
public class ServiceImpl implements Iservice{

	@Autowired
	IServiceDao serviceDaoImpl;
	
	@Override
	public List<com.cg.bean.Service> addService(com.cg.bean.Service service) {
		List<com.cg.bean.Service> serviceList = serviceDaoImpl.addService(service);
		return serviceList;
	}

	@Override
	public List<com.cg.bean.Service> deleteService(int serviceId) {
		List<com.cg.bean.Service> serviceList = serviceDaoImpl.deleteService(serviceId);
		return serviceList;
	}

	@Override
	public List<com.cg.bean.Service> fetchListOfServices() {
		List<com.cg.bean.Service> serviceList = serviceDaoImpl.fetchListOfServices();
		return serviceList;
	}

	@Override
	public void addSubservice(SubService subService) {
		serviceDaoImpl.addSubService(subService);
	}

	/*@Override
	public List<SubService> fetchListOfSubService() {
		List<SubService> subServiceList = serviceDaoImpl.fetchListOfSubService();
		return subServiceList;
	}*/

}
