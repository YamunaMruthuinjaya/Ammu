package com.cg.service;

import java.util.List;

import com.cg.bean.Service;
import com.cg.bean.SubService;

public interface Iservice {

	List<Service> addService(Service service);

	List<Service> deleteService(int serviceId);

	List<Service> fetchListOfServices();

	void addSubservice(SubService subService);

	//List<SubService> fetchListOfSubService();

}
