package com.cg.dao;

import java.util.List;

import com.cg.bean.Service;
import com.cg.bean.SubService;

public interface IServiceDao {

	List<Service> addService(com.cg.bean.Service service);

	List<Service> deleteService(int serviceId);

	List<com.cg.bean.Service> fetchListOfServices();

	void addSubService(SubService subService);

	//List<SubService> fetchListOfSubService();

}
