package com.cg.trainee.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.trainee.dao.ITraineeDAO;
import com.cg.trainee.dto.TraineeDTO;
@Service("traineeService")
public class TraineeServiceImpl implements ITraineeService{
	@Autowired
	ITraineeDAO traineeDAO;
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public boolean addTraineDetails(TraineeDTO traineeDTO) {
		//traineeDAO.beginTransaction();
		boolean tRF=traineeDAO.addTraineDetails(traineeDTO);
		return tRF;
		//traineeDAO.commitTransaction();
		
	}
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public TraineeDTO deleteTraineeDetails(Integer traineeID) {
		
		 return traineeDAO.deleteTraineeDetails(traineeID);
		
	}
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public TraineeDTO retriveDetails(Integer traineeID) {
		return traineeDAO.retriveDetails(traineeID);
	}
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public List<TraineeDTO> retriveOneDetails() {
		return traineeDAO.retriveOneDetails();
	}
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public TraineeDTO modifyDetailsById(Integer traineeID) {
		
		return traineeDAO.modifyDetailsById(traineeID);
	}
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	@Override
	public void modifyTraineeDetails(TraineeDTO traineeDTO) {
		traineeDAO.modifyTraineeDetails(traineeDTO);
	}
}
