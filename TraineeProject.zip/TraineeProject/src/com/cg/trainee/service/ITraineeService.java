package com.cg.trainee.service;

import java.util.List;

import com.cg.trainee.dto.TraineeDTO;

public interface ITraineeService {

	public boolean addTraineDetails(TraineeDTO traineeDTO);

	public TraineeDTO deleteTraineeDetails(Integer traineeID);

	public TraineeDTO retriveDetails(Integer traineeID);

	public List<TraineeDTO> retriveOneDetails();

	public TraineeDTO modifyDetailsById(Integer traineeID);

	public void modifyTraineeDetails(TraineeDTO traineeDTO);

}
