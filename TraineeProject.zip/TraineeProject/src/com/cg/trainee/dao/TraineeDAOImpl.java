package com.cg.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.trainee.dto.TraineeDTO;
@Repository("traineeDAO")

public class TraineeDAOImpl implements ITraineeDAO{
	 @PersistenceContext
		EntityManager entityManager;
	 
	@Override
	public boolean addTraineDetails(TraineeDTO traineeDTO) {
		
		TraineeDTO tdto=entityManager.find(TraineeDTO.class, traineeDTO.getTraineeId());
		if(tdto==null){
			entityManager.persist(traineeDTO);
			return true;
		}
		else{
			return false;
		}
	}

	@Override
	public TraineeDTO deleteTraineeDetails(Integer traineeID) {
	
		//Query queryOne=entityManager.createQuery("FROM TraineeDTO WHERE traineeId=:TID");
		/*Query queryTwo=entityManager.createQuery("FROM TraineeDTO where traineeId=:TID");
		queryTwo.setParameter("TID",traineeID);
		List<TraineeDTO> traineeDTO=queryTwo.getResultList();*/
		//TraineeDTO tdto= traineeDTO.get(0);
		TraineeDTO tdto= entityManager.find(TraineeDTO.class, traineeID);
		if(tdto==null)
			return null;
		else
			entityManager.remove(tdto);
		return tdto;
	}

	@Override
	public TraineeDTO retriveDetails(Integer traineeID) {
		/*Query query=entityManager.createQuery("FROM TraineeDTO where traineeId=:TID");
		query.setParameter("TID",traineeID);
		System.out.println("1");
		List<TraineeDTO> traineeDTO=query.getResultList();
		System.out.println("2");*/
		return entityManager.find(TraineeDTO.class, traineeID);
	}

	@Override
	public List<TraineeDTO> retriveOneDetails() {
		Query query=entityManager.createQuery("FROM TraineeDTO");
		return query.getResultList();
	}

	@Override
	public TraineeDTO modifyDetailsById(Integer traineeID) {
		
		return entityManager.find(TraineeDTO.class, traineeID);
	}

	@Override
	public void modifyTraineeDetails(TraineeDTO traineeDTO) {
		
		entityManager.merge(traineeDTO);
	}

}
