package com.cg.trainee.dao;

import java.util.List;

import com.cg.trainee.dto.TraineeDTO;

public interface ITraineeDAO {

	public boolean addTraineDetails(TraineeDTO traineeDTO);

	public TraineeDTO deleteTraineeDetails(Integer traineeID);

	public TraineeDTO retriveDetails(Integer traineeID);

	public List<TraineeDTO> retriveOneDetails();

	public TraineeDTO modifyDetailsById(Integer traineeID);

	public void modifyTraineeDetails(TraineeDTO traineeDTO);

}
