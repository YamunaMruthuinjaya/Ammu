package com.cg.trainee.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;
@Entity
@Table(name="TraineeTable")
@Component
public class TraineeDTO {
	@Id
	@Column(name="TID",nullable=false)
	//@Valid
	//@NotEmpty(message="Please Enter Trainee Id")
	//@Pattern(regexp = "^[0-9]{3,}$",message="Trainee Id must contain only Numbers")
	private Integer traineeId;
	
	@Column(name="TName")
	@Valid
	@NotEmpty(message="Please Enter Trainee Name")
	@Pattern(regexp = "^[A-Z]{1}[a-z]{3,}$",message="Trainee Name must contain only alphabets")
	private String traineeName;
	
	@Column(name="TDomain")
	@NotEmpty(message="Please Enter Trainee Domain")
	private String traineeDomain;
	@Column(name="TLocation")
	@NotEmpty(message="Please Enter Trainee Location")
	private String traineeLocation;
	public Integer getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(Integer traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	@Override
	public String toString() {
		return "TraineeDTO [traineeId=" + traineeId + ", traineeName="
				+ traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLocation=" + traineeLocation + "]";
	}
	
}
