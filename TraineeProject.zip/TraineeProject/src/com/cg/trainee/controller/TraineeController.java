package com.cg.trainee.controller;


import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.trainee.dto.Login;
import com.cg.trainee.dto.TraineeDTO;
import com.cg.trainee.service.ITraineeService;


@Controller

public class TraineeController {
	
	@Autowired
	ITraineeService traineeService;
	
	@RequestMapping(value="/traineeLogin")
	public String traineeLogin(Model model){
		
		 model.addAttribute(new Login());
		return "login";
		
	}
	
	@RequestMapping(value="/checkLogin")
	public String checkLogin(@RequestParam("userName") String uname,@RequestParam("password") String password){
		if(uname.equals("Admin")&&password.equals("password")){
			return "traineeMS";
		}
		else
			return "error";
	}
	
	@RequestMapping(value="/addTrainee",method=RequestMethod.GET)
	public String addTrainee(@ModelAttribute("traineedto") TraineeDTO traineeDTO,Model model, BindingResult result){
		model.addAttribute(new TraineeDTO());
		return "addTrainee";
	}
	
	@RequestMapping(value="/addDetails",method=RequestMethod.POST)
	public String addTraineeDetails(@ModelAttribute("traineedto") @Valid TraineeDTO traineeDTO,BindingResult result,Model model){
		
		if(result.hasErrors())
			return "addTrainee";
		else{
			model.addAttribute("id",traineeDTO.getTraineeId());
			boolean tRF= traineeService.addTraineDetails(traineeDTO);
			if(tRF)
				return "sucess";
			else
				return "errorId";
		}
		
	}
	
	@RequestMapping(value="/deleteTrainee",method=RequestMethod.GET)
	public String deleteTrainee(@ModelAttribute("traineedto") @Valid TraineeDTO traineeDTO,BindingResult result,Model model){
		return "deleteTrainee";
	}
	
	@RequestMapping(value="/deleteTDetails",method=RequestMethod.POST)
	public ModelAndView deleteTraineeDetails(@RequestParam("traineeId") Integer traineeID,@ModelAttribute("traineedto") @Valid TraineeDTO traineeDTO,BindingResult result,Model model){
		TraineeDTO traineeDto;
		
		traineeDto=traineeService.deleteTraineeDetails(traineeID);
		if(traineeDto==null){
			return new ModelAndView("retriveFail","traineeID",traineeID);
		}
		else
			return new ModelAndView("deleteTrainee","traineeDto",traineeDto);
	}
	
	@RequestMapping(value="/reallTrainee",method=RequestMethod.GET)
	public ModelAndView retriveAllDetails(@ModelAttribute("traineedto") @Valid TraineeDTO traineeDTO,BindingResult result,Model model){
		List<TraineeDTO> traineeDto=traineeService.retriveOneDetails();
		return new ModelAndView("retriveAll","traineeDto",traineeDto);
	}
	
	@RequestMapping(value="/retriveTrainee",method=RequestMethod.GET)
	public String retriveOne(@ModelAttribute("traineedto") @Valid TraineeDTO traineeDTO,BindingResult result,Model model){
		return "retriveOne";
	}
	
	@RequestMapping(value="/retriveAlldetails",method=RequestMethod.POST)
	public ModelAndView retriveDetails(@RequestParam("traineeId") Integer traineeID,@ModelAttribute("traineedto") @Valid TraineeDTO traineeDTO,BindingResult result,Model model){
		TraineeDTO traineeDto=traineeService.retriveDetails(traineeID);
		if(traineeDto==null){
			return new ModelAndView("retriveFail","traineeID",traineeID);
		}
		else
			return new ModelAndView("retriveOne","traineeDto",traineeDto);
	}
	
	@RequestMapping(value="/modifyTrainee",method=RequestMethod.GET)
	public String modifyTrainee(@ModelAttribute("traineedto") @Valid TraineeDTO traineeDTO,BindingResult result,Model model){
		return "modifyTrainee";
	}
	
	@RequestMapping(value="/modifyId",method=RequestMethod.POST)
	public ModelAndView modifyDetails(@RequestParam("traineeId") Integer traineeID,@ModelAttribute("traineedto") @Valid TraineeDTO traineeDTO,BindingResult result,Model model){
		TraineeDTO traineeDto=traineeService.modifyDetailsById(traineeID);
		if(traineeDto==null){
			return new ModelAndView("retriveFail","traineeID",traineeID);
		}
		else
			return new ModelAndView("modifyTrainee","traineeDto",traineeDto);
	}
	
	@RequestMapping(value="/modifyDetails",method=RequestMethod.POST)
	public String modifyTraineeDetails(@ModelAttribute("traineedto") @Valid TraineeDTO traineeDTO,BindingResult result,Model model){
		
		if(result.hasErrors())
			return "addTrainee";
		else{
			 traineeService.modifyTraineeDetails(traineeDTO);
		}
		return "sucess";
	}
}
