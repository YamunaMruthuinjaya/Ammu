package com.cg;

public class Emp {
	String name;
	int age;
	String company;
	boolean flag;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	@Override
	public String toString() {
		return "Emp [name=" + name + ", age=" + age + ", company=" + company
				+ ", flag=" + flag + "]";
	}
	
	
}
