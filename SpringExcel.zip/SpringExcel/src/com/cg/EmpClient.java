package com.cg;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class EmpClient {
	public static void main(String[] args) throws IOException {
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("emp.xml");
		Emp emp = (Emp) ctx.getBean("emp");
		
		File excel = new File("C:/Users/ymruthui/Desktop/Eclipse_Luna/eclipse/workspace/SpringExcel/Book.xlsx"); 
		FileInputStream fis = new FileInputStream(excel); 
		
		XSSFWorkbook book = new XSSFWorkbook(fis);
		XSSFSheet sheet = book.getSheetAt(0); 
	    
		Iterator<Row> itr = sheet.iterator(); 
		
		while (itr.hasNext()) {
			
			Row row = itr.next(); 			
			Iterator<Cell> cellIterator = row.cellIterator(); 
			int cellNum=0;
			
			while (cellIterator.hasNext()) { 
				
				Cell cell = cellIterator.next(); 
				cellNum++;
				
				if(cellNum==1){
					emp.setName(cell.getStringCellValue());
				}
				
				else if(cellNum==2){
					double age = cell.getNumericCellValue();
					int age1=(int)age;
					emp.setAge(age1);
				}
				
				else if(cellNum==3){
					emp.setCompany(cell.getStringCellValue());
				}
				
				else if (cellNum==4) {
					emp.setFlag(cell.getBooleanCellValue());
				}
			
			} 
			//System.out.println(emp);
			System.out.println(emp.getName()+"\t"+emp.getAge()+"\t"+emp.getCompany()+"\t"+emp.isFlag());
		}

	}
}
