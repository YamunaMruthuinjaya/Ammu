package com.cg.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;




import org.springframework.web.servlet.ModelAndView;

import com.cg.employee.pojo.Employee;
import com.cg.employee.service.IEmployeeService;

@Controller
public class EmployeeController {
	
	@Autowired
	IEmployeeService iService;
	
	@RequestMapping("/empform")
	public ModelAndView showForm(){
		return new ModelAndView("empform","command",new Employee());
	}
	
	@RequestMapping(value="/save",method = RequestMethod.POST)
	public ModelAndView save(@ModelAttribute("emp")Employee emp){
		iService.save(emp);
		 return new ModelAndView("redirect:/viewemp");
	}
	
	@RequestMapping("/viewemp")
	public ModelAndView viewEmp(){
		List<Employee> list = iService.getEmployees();
		System.out.println("list"+list);
		return new ModelAndView("viewEmp","list",list);
	}
	
	/*@RequestMapping("/viewemp")
	public String viewEmp(){
		List<Employee> list = iService.getEmployees();
		System.out.println("list"+list);
		return "viewEmp";
	}*/
	
	@RequestMapping(value="/deleteemp/{id}",method = RequestMethod.GET)
	public ModelAndView deleteById(@PathVariable int id){
		iService.deleteByID(id);
		return new ModelAndView("redirect:/viewemp");
	}

}
