package com.cg.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employee.dao.IEmployeeDAO;
import com.cg.employee.pojo.Employee;

@Service
public class EmployeeService implements IEmployeeService {
	
	@Autowired
    IEmployeeDAO employeeDAO;
	
	public int save(Employee emp) {
	   return employeeDAO.save(emp);
		
	}

	public List<Employee> getEmployees() {
		return employeeDAO.getEmployees();
	}

	public int deleteByID(int id) {
		return employeeDAO.deleteById(id);
	}

}
