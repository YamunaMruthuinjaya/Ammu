package com.cg.employee.service;

import java.util.List;

import com.cg.employee.pojo.Employee;

public interface IEmployeeService {

	public int save(Employee emp);

	public List<Employee> getEmployees();

	public int deleteByID(int id);

}
