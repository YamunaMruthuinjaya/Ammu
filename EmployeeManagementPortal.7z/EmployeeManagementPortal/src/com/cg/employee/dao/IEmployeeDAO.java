package com.cg.employee.dao;

import java.util.List;

import com.cg.employee.pojo.Employee;

public interface IEmployeeDAO {

	public int save(Employee emp);

	public List<Employee> getEmployees();

	public int deleteById(int id);

}
