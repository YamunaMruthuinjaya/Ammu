package com.cg.employee.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.cg.employee.pojo.Employee;

@Repository
public class EmployeeDAO implements IEmployeeDAO {

	/*public JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}*/
	@Autowired
	JdbcTemplate jdbcTemplate;

	/*public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}*/

	public int save(Employee emp) {
		String query="insert into employee values("+emp.getId()+",'"+emp.getName()+"',"+emp.getSalary()+",'"+emp.getDesignation()+"')";
		 return jdbcTemplate.update(query);
		
	}

	public List<Employee> getEmployees() {
		return jdbcTemplate.query("select * from employee",new RowMapper<Employee>(){

			public Employee mapRow(ResultSet res, int rowNumber)
					throws SQLException {
				Employee employee  = new Employee();
				employee.setId(res.getInt(1));
				employee.setName(res.getString(2));
				employee.setSalary(res.getFloat(3));
				employee.setDesignation(res.getString(4));
				return employee;
			}
			
		});
	}

	public int deleteById(int id) {
		String query="delete from employee where id = "+id+"";
		return jdbcTemplate.update(query);
	}

}
