package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.cg.dto.Student;
import com.cg.exception.StudException;

@Repository
public class StudDaoImpl implements IStudDao{
	/*@Autowired
	private JdbcTemplate jdbcTemplate;*/
	
	@Autowired
	private SessionFactory sessionFactory;
	

	@Override
	public boolean registerStud(Student stud) {
			// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
        session.beginTransaction();
        session.save(stud);
        session.getTransaction().commit(); 
        session.close();
		return true;
	}


	@Override
	public List<Student> fetchStuds() throws StudException {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
        List<Student> studList = session.createQuery("from Student").list();
        session.close(); 
        if(studList!=null){
		return studList;
        }
        else{
        	throw new StudException("The records are not available");
        }
	}


	@Override
	public Student delStud(int sId) throws StudException {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
        session.beginTransaction(); 
        Student stud = (Student) session.get(Student.class, sId); 
        if(stud!=null){
        	session.delete(stud);
        	session.getTransaction().commit(); 
        	session.close();
        	return stud;}
        else{
        	throw new StudException("The records to be deleted is not available");
        }
	}


	@Override
	public Student ViewStud(int sId) throws StudException {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
        session.beginTransaction(); 
        Student stud = (Student) session.get(Student.class, sId); 
        if(stud!=null){
        	session.getTransaction().commit(); 
        	session.close();
        	return stud;
        }
        else{
        	throw new StudException("The record to be viewed is not available");
        }
        
	}

}
