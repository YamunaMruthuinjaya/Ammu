package com.cg.controller;


import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dto.Student;
import com.cg.exception.StudException;
import com.cg.service.IStudService;
import com.cg.service.StudServiceImpl;


@Controller
public class StudContoller {
	
	@Autowired
	IStudService studService;
	
	public IStudService getStudService() {
		return studService;
	}

	public void setStudService(IStudService studService) {
		this.studService = studService;
	}
	
	@RequestMapping("/home")
	public String home(){
		return "index";
	}
	
	@RequestMapping("/register")
	public ModelAndView register(){
		System.out.println("in reguster");
		return new ModelAndView("register","stud",new Student());
	}

	@RequestMapping(value="/reg",method = RequestMethod.POST)
	public ModelAndView reg( @ModelAttribute("stud") @Valid  Student stud ,BindingResult result){
		if(result.hasErrors()){
			return new ModelAndView("register");
		}
		
		boolean flag = studService.registerStud(stud);
		if(flag){
			return new ModelAndView("success","s",stud);
		}
		else{
			return new ModelAndView("failure","sname",stud.getStudName()); 
		}		
	}
	
	@RequestMapping("/display")
	public ModelAndView display(){
		List<Student> studList = new ArrayList<Student>();
		try{
		
		studList = studService.fetchStuds();
		
		}catch(StudException e){
		return new ModelAndView("ErrorPage","err",e.getMessage());
	}return new ModelAndView("display","sList",studList);
	}
	
	@RequestMapping("/view")
	public String view(){
		return "viewIndividual";
	}
	
	@RequestMapping("/viewIndi")
	public ModelAndView viewIndi(@RequestParam("studId") int sId){
		Student stud;
		try{
			stud = studService.ViewStud(sId);
		}catch(StudException e){
			return new ModelAndView("ErrorPage","err",e.getMessage());
		}
		return new ModelAndView("ViewSuccess","stud",stud);
	}
	
	@RequestMapping("/delete")
	public String delete(){
		return "delete";
	}
	
	@RequestMapping("/del")
	public ModelAndView del(@RequestParam("studId") int sId){
		Student stud;
		try{
			stud = studService.delStud(sId);
		}catch(StudException e){
			return new ModelAndView("ErrorPage","err",e.getMessage());
		}
		return new ModelAndView("DelSuccess","stud",stud);
	}
	
	
	
}
