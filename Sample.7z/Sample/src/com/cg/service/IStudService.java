package com.cg.service;

import java.util.List;

import com.cg.dto.Student;
import com.cg.exception.StudException;

public interface IStudService {

	boolean registerStud(Student stud);

	List<Student> fetchStuds() throws StudException;

	Student delStud(int sId) throws StudException;

	Student ViewStud(int sId) throws StudException;

}
