package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IStudDao;
import com.cg.dao.StudDaoImpl;
import com.cg.dto.Student;
import com.cg.exception.StudException;

@Service
public class StudServiceImpl implements IStudService{
	@Autowired
	IStudDao studDao;
	
	public IStudDao getStudDao() {
		return studDao;
	}

	public void setStudDao(IStudDao studDao) {
		this.studDao = studDao;
	}

	@Override
	public boolean registerStud(Student stud) {
		// TODO Auto-generated method stub
		//studDao = new StudDaoImpl();
		boolean flag = studDao.registerStud(stud);
		return flag;
	}

	@Override
	public List<Student> fetchStuds() throws StudException {
		// TODO Auto-generated method stub
		List<Student> studList = new ArrayList<Student>();
		studList = studDao.fetchStuds();
		return studList;
	}

	@Override
	public Student delStud(int sId) throws StudException {
		// TODO Auto-generated method stub
		Student stud = studDao.delStud(sId);
		return stud;
	}

	@Override
	public Student ViewStud(int sId) throws StudException {
		// TODO Auto-generated method stub
		Student stud = studDao.ViewStud(sId);
		return stud;
	}

}
