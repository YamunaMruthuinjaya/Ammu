package com.cg.exception;

public class StudException extends Exception{

	public StudException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	
	
}
