package com.igate.controller;

import java.io.Console;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartRequest;

import com.igate.form.FileUploadForm;

@Controller
public class FileUploadController {
	
	
	@RequestMapping(value="/fileUpload")
	
	public String uploadFile(Model model){
		model.addAttribute("uploadForm",new FileUploadForm());
		return "fileUpload";
	}
	
	@RequestMapping(value = "/show", method = RequestMethod.GET)
	public String displayForm() {
		
		return "file_upload_form";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String save(@ModelAttribute("uploadForm") FileUploadForm uploadForm,
			Model map) {

		MultipartFile multipartFile = uploadForm.getFile();

		String fileName = "";

		if (multipartFile != null) {
			fileName = multipartFile.getOriginalFilename();
			
			System.out.println(fileName);
			//size = multipartFile.getContentLength();
			System.out.println("File Size: "+ multipartFile.getSize() + " bytes");  
			
			MultipartRequest m=new MultipartRequest(request,"d:/new");  //d is directory to upload file
			System.out.println("successfully uploaded"); 
		}
		

		map.addAttribute("files", fileName);
		return "success";
	}


}
