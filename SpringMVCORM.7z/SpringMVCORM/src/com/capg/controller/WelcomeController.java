package com.capg.controller;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.capg.DAOInt.UserDAOInterface;
import com.capg.JavaBeans.User;
import com.capg.serviceInt.UserServiceInterface;

@Controller
public class WelcomeController {
	
	private static Logger log = Logger.getLogger(WelcomeController.class);
	
	@Autowired
	private UserServiceInterface usi;
		
	public UserServiceInterface getUsi() {
		return usi;
	}

	public void setUsi(UserServiceInterface usi) {
		this.usi = usi;
	}

	@RequestMapping("/preLogin")
	public ModelAndView message(){
		log.info("We are in WelcomeController");
		String message = "Please Login";
		return new ModelAndView("Login","message",message);
	}
	
	@RequestMapping("/userLoginCheck.html")
	public ModelAndView loginCheck(@ModelAttribute("user") User user){
		System.out.println("Hi I am in LoginCheck");
		usi.getUser(user);
		ModelAndView model = new ModelAndView("LoginSuccess");
		model.addObject("message","Welcome to EzTrac System");
		return null;
	}
	
	@RequestMapping("/saveUser.html")
	public ModelAndView saveUser(@ModelAttribute("user") User user){
		System.out.println("Hi I am in saveUser");
		ModelAndView model = new ModelAndView("LoginSuccess");
		model.addObject("message","Welcome to EzTrac System");
		usi.save(user);
		System.out.println(user.getUserid()+" "+user.getUsername()+" "+user.getPassword());
		System.out.println("Saved User Successfully");
		return model;
	}
}
