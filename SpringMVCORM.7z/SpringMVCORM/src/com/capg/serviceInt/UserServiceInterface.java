package com.capg.serviceInt;

import com.capg.JavaBeans.User;

public interface UserServiceInterface {
	
	public void save(User user);
	public void update(User user);
	public void delete(User user);
	public User getUser(User user);
}
