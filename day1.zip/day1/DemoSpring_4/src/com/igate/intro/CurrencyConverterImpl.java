package com.igate.intro;
public class CurrencyConverterImpl implements CurrencyConverter {
	
	public CurrencyConverterImpl() {
		System.out.println("CurrencyConverterImpl()");
	}

	private ExchangeService exchangeService1;

	public ExchangeService getExchangeService() {
		System.out.println("getExchangeService()");		
		return exchangeService1;
	}

	public void setExchangeService(ExchangeService exchangeService) {
		System.out.println("setExchangeService()");		
		this.exchangeService1 = exchangeService;
	}

	public double dollarsToRupees(double dollars) {
		System.out.println("dollarsToRupees()");		
		return dollars * exchangeService1.getExchangeRate();
	}
};