package com.igate.intro;

public class CurrencyConverterImpl implements CurrencyConverter {
	
	private double exchangeRate;
	private double a;
	
	public double getExchangeRate() {
		System.out.println("getExchangeRate()");		
		return exchangeRate;
	}

	public void setExchangeRate(double exchangeRate) {
		System.out.println("setExchangeRate()");		
		this.exchangeRate = exchangeRate;
	}
	
	public double getA() {
		System.out.println("getA()");		
		return a;
	}

	public void setA(double a) {
		System.out.println("setA()");		
		this.a = a;
	}

	public double dollarsToRupees(double dollars) {
		System.out.println("dollarsToRupees()");
		System.out.println(this.getA());
		this.setA(000.09);
		System.out.println(this.getA());
		return dollars * exchangeRate;
	}
};